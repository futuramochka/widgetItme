var notifications_market = {};

document.addEventListener('init', function () {
	
})